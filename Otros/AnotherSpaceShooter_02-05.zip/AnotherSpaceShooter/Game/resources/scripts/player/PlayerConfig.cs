﻿
using System;

namespace Game
{
    public class PlayerConfig
    {

    }
}