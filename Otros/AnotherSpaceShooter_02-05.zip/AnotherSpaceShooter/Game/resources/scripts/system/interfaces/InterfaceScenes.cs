﻿namespace Game
{
    public interface InterfaceScenes
    {
        void Start();
        void Update();
        void Render();
        void Finish();
    }
}
