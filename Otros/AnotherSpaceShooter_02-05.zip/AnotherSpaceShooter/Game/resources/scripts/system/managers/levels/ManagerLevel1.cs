﻿

namespace Game
{
    class ManagerLevel1
    {
    }
}
