﻿

namespace Game
{
    class ManagerLevel2
    {
    }
}
