﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;

namespace Game
{
    public enum Scenes { MainMenu, Level1, Defeat, Victory }
    public class GameplayManager
    {
        private static GameplayManager instance;
        private InterfaceScenes currentScene = null; // Interface?
        private MainMenu mMain;

        public static GameplayManager Instance
        {
            get { if (instance == null) instance = new GameplayManager(); return instance; }
        }

        private static int currentLifes = 3;
        private readonly static float[] lifesPositionsOnScreen = { 30, 90, 150, 210, 270, 50 }; // Positions in X - X - X and Y 
        private static ShipConfig playerShip = null;

        public void InitializeGame()
        {
            Textures.InitializeTextures();

            // Initialize menues
            mMain = new MainMenu(); // Interface?

            Player.InitializePlayer(ShipsData.GetShipConfig(0));
            DummyEnemy.InitializeDummy(ShipsData.GetShipConfig(3));
            SoundPlayer sfx = new SoundPlayer("resources/sfx/fbattery_loop.wav");
            sfx.PlayLooping();
            SFX.PlayMusic();

            InitializeGameplayManager();
            AllStar();

            ChangeScene(Scenes.MainMenu); // Interface?
        }

        // Interface?
        public void ChangeScene(Scenes toWhat) // Interface?
        {
            if (currentScene != null) currentScene.Finish();

            currentScene = mMain;
            currentScene.Start();
        }

        public static void InitializeGameplayManager()
        {
            playerShip = Player.GetShip();
            Player.OnShipDestroyed += LifeLost;
        }

        private protected static void LifeLost()
        {
            --currentLifes;
            Console.WriteLine("GameplayManager --> El jugador perdió una vida.");
        }

        public void ManagerUpdate()
        {
            StarsManager.UpdateBack();

            DummyEnemy.Update();
            Player.Update();
            CollisionManager.Update();
            ProyectilesManager.Update();
            LifesOnScreen();

            StarsManager.UpdateFront();

            currentScene.Update(); // Interface?
        }

        private static void LifesOnScreen()
        {
            if (playerShip != null && currentLifes > 0)
            {
                for (int i = 0; i < currentLifes; i++)
                {
                    if (i == currentLifes - 1)
                        Engine.Draw(Player.GetIntegrityTexture(), lifesPositionsOnScreen[i], lifesPositionsOnScreen[5], 0.4f, 0.4f);
                    else if (i != currentLifes) 
                        Engine.Draw(playerShip.ShipAnim().GetFrameTexture(playerShip.ShipAnim().AnimationLongitude() - 1), lifesPositionsOnScreen[i], lifesPositionsOnScreen[5], 0.4f, 0.4f);
                }
            }
        }

        private static void AllStar()
        {
            for (int i = 0; i < 30; i++)
                StarsManager.AddBackStar(new Star());
            for (int i = 0; i < 30; i++)
                StarsManager.AddFrontStar(new Star());
        }
    }
}