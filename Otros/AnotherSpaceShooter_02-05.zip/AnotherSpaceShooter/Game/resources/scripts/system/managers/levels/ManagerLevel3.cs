﻿

namespace Game
{
    class ManagerLevel3
    {
    }
}
