﻿

using System;
using System.Numerics;

namespace Game
{
    class MainMenu : InterfaceScenes
    {
        private Button start;
        private Vector2 startPos = new Vector2 (100,300);

        private Button credits;
        private Vector2 creditsPos = new Vector2(500, 800);

        private Button exit;
        private Vector2 exitPos = new Vector2(500, 300);

        private float delay = 0.2f;
        private float currentDelay = 0;
        private bool allowInput = true;
        private Button selected;
        private Action KeyInput;

        public MainMenu()
        {

        }

        public void Start()
        {
            start = new Button(startPos, 1, UI.GetUITextures(0));
            credits = new Button(creditsPos, 1, UI.GetUITextures(0));
            exit = new Button(exitPos, 1, UI.GetUITextures(0));

            start.AssignButtons(exit, credits);
            credits.AssignButtons(start, exit);
            exit.AssignButtons(credits, start);

            selected = start;
            KeyInput += ResetInputDelay;
        }

        private void ResetInputDelay()
        {
            currentDelay = 0;
            allowInput = false;
        }

        public void Update()
        {
            if (!allowInput) currentDelay += Program.GetDeltaTime();
            if (currentDelay >= delay && !allowInput)
            {
                currentDelay = 0;
                allowInput = true;
            }

            if (Engine.GetKey(Keys.F) && allowInput)
            {
                allowInput = false;
                Selection(selected.PreviousButton);
            }

            if (Engine.GetKey(Keys.G) && allowInput)
            {
                allowInput = false;
                Selection(selected.NextButton);
            }

            start.Update(); credits.Update(); exit.Update();
        }

        public void Render()
        {
            start.Update();
        }


        public void SelectionSelect()
        {
            if (selected != null)
            {
                if (selected == start)
                    Console.WriteLine("Start level 1?");

                if (selected == credits)
                    Console.WriteLine("Credits?");

                if (exit == credits)
                    Console.WriteLine("Exit?");
            }
        }

        public void Selection(Button current)
        {
            if (selected != null)
            {
                selected.Unselected();
            }

            selected = current;
            selected.Selected();
        }

        public void Finish()
        {
            Console.WriteLine("Clear everything?");
        }

    }
}
